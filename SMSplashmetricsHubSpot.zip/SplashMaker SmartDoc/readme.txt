=== SplashMaker ===
Contributors: splashmetrics, watershed5, MOWWs5
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tags: Smart Content, Content Personalization, Forms, CRM, Automation, Analytics
Requires at least: ?????
Tested up to: ?????
Requires PHP: ?????
Stable tag: ?????

The Smart Content Engine for WordPress that provides for dynamically personalized content, marketing automation and CRM integration, and Splashmetrics Buyer Journey intelligence and analytics.

== Description ==

THE MOST EASY TO USE, POWERFUL, AND EXTENSIBLE SMART CONTENT PLUGIN FOR WORDPRESS

<a href="https://splashmetrics.io/product-category/splashmaker-products/" target="_blank">SplashMaker</a> provides for dynamically personalized content, marketing automation and CRM integration, and Splashmetrics Buyer Journey intelligence and analytics.

With the SplashMaker Basic free plugin you can easily:

- Create intelligent Personalization Forms that automatically generate personalization tokens to be used in the content titles and copy, and that dynamically serve users the specific content experience that fits their needs.
- Manage the Personalization Form submissions to keep track of leads and Buyer data.
- Build beautiful, responsive, and fully personalized SmartDocs inside WordPress, providing your users completely bespoke content experiences instead of traditional, static PDFs.

The free SplashMaker Basic WordPress plugin includes the following:

**PERSONALIZATION FORM**

The functionality and UI of this component differs slightly depending on whether you have the basic or premium package.

This section is pretty straightforward, but as with many pages in SplashMaker, you can use the info-pop-ups to get more information on each item as necessary.

Also, you’ll notice that you can drag-and-drop the order of the fields as desired. Just use the icon to the right of the row.

Generally, this component works like many other WordPress contact form plugins with a few critical distinctions:

Form Fields
Personalization Token: Use these tokens in your Dynamic Content headings, paragraph copy, etc. to personalize that text for the Buyer. For example if you enter “Hi [splash_token field=first_name]!” The Buyer’s first name will be used in that spot. To copy a token for use in your content, simply click in its blue field and use your preferred method of copying that item to your clipboard.

Email: You’ll notice that by default, we already have the Email form item here. The reason for this is that most Marketing Automation and CRM platforms require emails for their forms/contacts. As you’ll see in the info-pop-up, if you are using the free version of SplashMaker, you can delete this field if you’d like to create a fully custom form. Otherwise, if you have a third-party integration, it is locked.

Dynamic Content Driver: This is another default item in the form. It determines which Dynamic Content page is served to the user based on their selection. The dropdown values are automatically generated based on the titles of the Dynamic Content pages you create. So just create the pages/versions you want to offer, enter a label for this dropdown to match the context of those pages/versions, and SplashMaker takes care of the rest.

Form Pop-Up Shortcode: Place this shortcode into the main landing page for this Smart Content asset*. The pop-up will automatically present this form to allow the user to drive the Dynamic Content Experiences you’ve defined for this asset. To copy the shortcode, simply click in its blue field and use your preferred method of copying that item to your clipboard.

(*Note: If you have one of our premium SmartDoc themes, we’ve already taken care of this for you.)

Add Fields
There are 2 types of fields that can be added to the form, Standard and Custom. Simply make a Standard field selection, or enter the name of the Custom field you want to create and select “Add Field” as appropriate. The new field(s) will show up in the “Added Fields” section and the “Save Form” button will turn red indicating the change. Select that button to save the configuration and move these new fields to the form section above.

Here are the unique distinctions between the field types…

Add Standard Field: This will add the basic standard fields that are typically in forms. These are already fully mapped and correctly tokenized for you. Also, if you are using one of our premium packages with a Marketing Automation integration, these will be auto-mapped to that platform by SplashMaker – saving you a great deal of time and trouble.

Add Custom Field: This will add various custom field types such as Hidden, Text, TextArea, and Select. You can name the field as you see fit, and SplashMaker will use that to create the Personalization Token.

**DYNAMIC CONTENT**

This is the core smart content component of SplashMaker. It allows you to create custom pages that will be dynamically served to users via their selection from the dropdown items in the Dynamic Content Driver field of the form.

You simply create the page versions of the SmartDoc you want to present to your Buyers and name them to align with the above dropdown items. For example, you might use ABM buying roles such as End User, Influencer, and Decision Maker. Or Industry/Vertical versions, Country, Language, etc. You can use virtually any driver for these.

The Personalization Form component is directly tied to these Dynamic Content pages in 2 ways. First, whatever pages you create and title here, will automatically show up on the Dynamic Content Driver dropdown in the form. All that is automated for you by SplashMaker.

Additionally, the Personalization Tokens from the Personalization Form component – e.g. [splash_token field=firstname] - can be placed into your page content to further personalize the copy and titles with the Buyer’s name, company name, title, etc. This too is automated for you by SplashMaker after you place the token.

You just focus on building out the Personalization Form and your Dynamic Content pages – and SplashMaker takes care of the rest.

To make things even easier, we provide various SmartDoc and SmartApp WordPress themes that have most everything already set-up for you. You’ll find a growing library of assets like eBooks, Data Sheets, Infographics, Assessments, etc. See our premium products here: <a href="https://splashmetrics.io/product-category/splashmaker-products/" target="_blank">SplashMaker Store</a>.

And here are the premium add-ons you’ll find there which greatly extend the power of SplashMaker:

**SMARTDOC THEMES - PREMIUM**

Instead of traditional PDFs for your eBooks, Case Studies, White Papers, Data Sheets, etc. – imagine dynamically-customizing and fully-responsive digital versions that automatically personalize to each and every Buyer. Yet, those Buyers can still save that personalized document to a traditional PDF – it’s just a completely bespoke version that only they will have. Now that’s powerful! That’s SplashMaker SmartDocs.

The <a href="https://splashmetrics.io/product/smartdoc-theme/" target="_blank">SmartDoc Theme package</a> for WordPress provides 2 distinct versions of a fully-responsive SmartDoc that is already set up to do all of the above and is ready for you to edit and make your own. For example, the extremely light-yet-powerful theme package provides all the needed free plugins for the content as shown (including the SplashMaker Basic plugin). We’ve even set up and formatted the print feature for you so that the end-user can print or save their custom SmartDoc as a PDF!

So, with the SmartDoc Theme you can quickly – and affordably – create dynamically customizing eBooks, Case Studies, White Papers, Data Sheets and much, much more. All for what you would likely pay for outmoded static PDFs!

But – you can also take the design even further with other favorite WordPress plugins, widgets, etc. to make your Buyer Content Experiences like nothing else on the market. The sky's the limit!

This one-time fee SmartDoc Theme package includes:

-2 design versions of the custom content – with stand-in copy, graphics, effects, animations, etc. You just customize what’s there to your own needs. You can also have as many different versions as you’d like in each package. You have complete control. <a href="https://lifering.splashmetrics.com/knowledge-base/smartdoc-theme-usage/" target="_blank">(Support here.)</a>

-The SplashMaker Basic plugin for automatically serving up dynamic, personalized versions of the SmartDoc. You can also Go Premium with this plugin for integration with other platforms like Splashmetrics, HubSpot, etc. <a href="https://lifering.splashmetrics.com/knowledge-base/splashmaker-overview/" target="_blank">(Support here.)</a>

-All other required plugins so you can easily duplicate pages, customize the design blocks in the pages, print or save the existing layout to PDF, and much more.

*”Asset Sites” are individual WordPress installs for SmartContent Experiences containing multiple Dynamic Content pages.

**SPLASHMETRICS INTEGRATION - PREMIUM**

This annual subscription package provides all the basic tools of SplashMaker, but also adds the +Splashmetrics Platform Integration suite. This powerful, time-saving integration automates much of the setup of the various asset items (forms, scripts, pages, etc.) by leveraging the SplashLogic Specification you (the content creator) receive from a Splashmetrics customer.

With one click – most of this work is done for you!

This tool also provides a datapoint tester so that you can be sure your smart content is reporting the correct metrics to the Splashmetrics Analyze component. This way, you’re confident that your client is receiving the measurement data they expect.

The package includes:

-Personalization Form
-Dynamic Content
-Latest SmartDoc and SmartApp Content Themes
-Platform Integration
    –Splashmetrics
-Smart CTAs
-Integration Scripts
-LifeRing Premium Support

*”Asset Sites” are individual WordPress installs for SmartContent Experiences containing multiple Dynamic Content pages. This package will allow for a full-funnel, fully-customized, 5-stage Buyer Journey.


**SPLASHMETRICS+HUBSPOT INTEGRATION - PREMIUM**

This annual subscription package provides all the tools of SplashMaker+Splashmetrics, but also adds the +HubSpot Platform Integration suite. This powerful integration allows you to map the SplashMaker Personalization Form fields directly into HubSpot via an OAuth connection. But it also allows you to automatically setup and populate custom fields in HubSpot for Buyer interaction data from within the SmartContent.

Finally, it provides an automated personalization URL “SmartLink” to the SmartContent asset, complete with HubSpot personalization tokens, that you can provide your client. This allows your client’s HubSpot team to use this SmartLink within HubSpot to send known contacts directly to the asset with full personalization – but without having to deal with a form.

Greatly reduce the amount of time and cost put into the coordination and manual efforts of these kinds of MA/CRM integrations.

The toolset includes:

-Personalization Form
-Dynamic Content
-Latest SmartDoc and SmartApp Content Themes
-Platform Integration
    –Splashmetrics
    –HubSpot
-Smart CTAs
-Integration Scripts
-LifeRing Premium Support

*”Asset Sites” are individual WordPress installs for SmartContent Experiences containing multiple Dynamic Content pages. This package will allow for a full-funnel, fully-customized, 5-stage Buyer Journey.

**WHAT PEOPLE ARE SAYING ABOUT SPLASHMAKER**

“HubSpot was a big factor in helping us scale WP Buffs to $1M in revenue. Their plugin and sales CRM made our sales process so much more professional and kept us fully organized as we grew from 1 salesperson to 4. Plus, the reporting dashboards allow me to know where our sales game is strong and where we can still improve with just a few clicks. Needless to say, I'm all in on HubSpot.” – **Joe Howard, Founder & CEO, WP Buffs**

“HubSpot educates marketers beyond just the anonymous web analytics they get from Google Analytics. Instead, it digs down to individual users.” – **Michael Shoup, Founder / CEO, 12South Marketing**

“HubSpot dramatically cuts down the time I spend on marketing. We used to spend tons of time generating very few inbound leads, but those numbers have gone through the roof with minimal effort.” – **Brian Ruhlmann, Director of Sales & Marketing, AdmitHub**

== Installation ==

= Search =

The easiest way to install the SplashMaker Basic plugin is to use the WordPress Admin interface.

- Go to your admin dashboard
- Find the "Plugins" menu
- Click on "Add New"
- Search for "SplashMaker"
- Click "Install Now"
- Go to your "Plugins" menu
- Click "Activate" on the SplashMaker plugin
- Start creating Smart Content!

= Upload =

1. Upload the 'splashmaker' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

Having trouble? Check out our <a href="https://lifering.splashmetrics.com/knowledge-base/splashmaker-overview/" target="_blank">help documentation</a>

== Frequently Asked Questions ==

= Requirements =

- Your “Asset Site” (website) must be using WordPress.org version 5.0 or higher on your server. We recommend the latest version.
- The plugin cannot be installed on WordPress.com sites, as they do not allow you to add plugins or Javascript.
- The wp_footer function must be included in your WordPress theme’s footer file (footer.php).
- This function is required for our Javascript snippet to be installed on every page of your site.
- You must be a WordPress admin to be able to install plugins for your site. If you are not the admin, you can forward these instructions to the person who manages your WordPress install.

= What does the plugin do? =

With the SplashMaker Basic free plugin you can easily:

- Create intelligent Personalization Forms that automatically generate personalization tokens to be used in the content titles and copy, and that dynamically serve users the specific content experience that fits their needs.
- Manage the Personalization Form submissions to keep track of leads and Buyer data.
- Build beautiful, responsive, and fully personalized SmartDocs inside WordPress, providing your users completely bespoke content experiences instead of traditional, static PDFs.

= Are coding skills needed to use the SplashMaker plugin? =

Not at all! The SplashMaker plugin is easy to download and starts working seamlessly with your WordPress site right away.

= What is available for free with the SplashMaker Basic plugin? =

The SplashMaker Basic plugin provides a Personalization Form component and Dynamic Content pages that personalize the content experience to each user. It is free to use on as many Asset Sites as you’d like.

SplashMaker also has paid tiers available for those who want more advanced functionality like SmartContent Themes, Integration with leading marketing and sales platforms like Splashmetrics and Hubspot, Smart CTAs, Integration Scripts, and more.

If you'd like a complete view of the features offered in SplashMaker's free and paid tiers, view our <a href="https://splashmetrics.io/product-category/splashmaker-products/" target="_blank">product and pricing page</a>.

= My question is not listed. =

Please visit our <a href="https://lifering.splashmetrics.com/knowledge-base/splashmaker-overview/" target="_blank">LifeRing Knowledge Base</a> for more detailed documentation and support. Thank you!

== Screenshots ==

1. SplashMaker Splash Page
2. Personalization Form
3. Dynamic Content
4. Dynamic Content Edit Page 01
5. Dynamic Content Edit Page 02
6. Dynamic Content Edit Page 03
7. Dynamic Content Actual Page 01
8. Dynamic Content Actual Page 02
9. Dynamic Content Actual Page 03
10. Dynamic Content Actual Page 04
11. SmartDoc Publish PDF - PREMIUM
12. Platform Integrations - PREMIUM
13. Platform Integrations - Splashmetrics - PREMIUM
14. Platform Integrations - HubSpot - PREMIUM
15. SmartCTAs - PREMIUM
16. Integration Scripts - PREMIUM


This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).


== Changelog ==

= 1.0 =
* A change since the previous version.
* Another change.

= 0.5 =
* List versions from most recent at top to oldest at bottom.

== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.

= 0.5 =
This version fixes a security related bug.  Upgrade immediately.
