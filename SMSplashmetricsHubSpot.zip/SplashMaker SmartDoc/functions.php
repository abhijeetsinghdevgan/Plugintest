<?php 

require_once dirname( __FILE__ ) . '/framework/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'builder_theme_register_required_plugins' );

function builder_theme_register_required_plugins() {

   $plugins = array( 

   array(

           'name'               => 'Getwid', // The plugin name.
            'slug'               => 'getwid', // The plugin slug (typically the folder name).
           'source'             => get_template_directory_uri() . '/framework/plugins/getwid.zip', // The plugin source.
                      'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
            array(
            'name'               => 'Print-O-Matic', // The plugin name.
            'slug'               => 'print-o-matic', // The plugin slug (typically the folder name).
            'source'             => get_template_directory_uri() . '/framework/plugins/print-o-matic.zip', // The plugin source.
            'required'           => true, // If false, the plugin is only 'recommended' instead of required.
        ),
    // array(
    //         'name'               => 'Remove "Powered by Wordpress"', // The plugin name.
    //         'slug'               => 'remove-powered-by-wp', // The plugin slug (typically the folder name).
    //         'source'             => get_template_directory_uri() . '/framework/plugins/remove-powered-by-wp.zip', // The plugin source.
    //         'required'           => true, // If false, the plugin is only 'recommended' instead of required.
    //     ),
  
    array(
            'name'      => 'SplashMaker',
            'slug'      => 'splashmaker',
            'required'  => true,
         'source'=> get_template_directory_uri() . '/framework/plugins/splashmaker.zip', // The plugin source.
        ),

    array(
            'name'      => 'WP Floating Menu',
            'slug'      => 'wp-floating-menu',
            'required'  => true,
         'source'=> get_template_directory_uri() . '/framework/plugins/wp-floating-menu.zip', // The plugin source.
        ),

     array(
            'name'      => 'Duplicate Page',
            'slug'      => 'duplicate-page',
            'required'  => true,
         'source'=> get_template_directory_uri() . '/framework/plugins/duplicate-page.zip', // The plugin source.
        )
     


    );
    $config = array(
        'default_path' => '',                      // Default absolute path to pre-packaged plugins.
        'menu'         => 'tgmpa-install-plugins', // Menu slug.
        'has_notices'  => true,                    // Show admin notices or not.
        'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
        'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
        'is_automatic' => false,                   // Automatically activate plugins after installation or not.
        'message'      => '',                      // Message to output right before the plugins table.
        'strings'      => array(
            'page_title'                      => __( 'Install Required Plugins', 'tgmpa' ),
            'menu_title'                      => __( 'Install Plugins', 'tgmpa' ),
            'installing'                      => __( 'Installing Plugin: %s', 'tgmpa' ), // %s = plugin name.
            'oops'                            => __( 'Something went wrong with the plugin API.', 'tgmpa' ),
            'notice_can_install_required'     => _n_noop( 'IMPORTANT! This SplashMaker SmartDoc theme requires several free WordPress plugins such as SplashMaker and a few other supplementary plugins such as Getwid, Print-O-Matic, Duplicate Page, etc. Please install and activate them now', 'IMPORTANT! This SplashMaker SmartDoc theme requires several free WordPress plugins such as SplashMaker and a few other supplementary plugins such as Getwid, Print-O-Matic, Duplicate Page, etc. Please install and activate them now', 'tgmpa' ), // %1$s = plugin name(s).
            'notice_can_install_recommended'  => _n_noop( 'This theme recommends the following plugin: %1$s.', 'This heme recommends the following plugins: %1$s.', 'tgmpa' ), // %1$s = plugin name(s).
            'notice_cannot_install'           => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'tgmpa' ), // %1$s = plugin name(s).

            'notice_can_activate_required'    => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'tgmpa' ), // %1$s = plugin name(s).
            'notice_can_activate_recommended' => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'tgmpa' ), // %1$s = plugin name(s).

            'notice_cannot_activate'          => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'tgmpa' ), // %1$s = plugin name(s).

            'notice_ask_to_update'            => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'tgmpa' ), // %1$s = plugin name(s).

            'notice_cannot_update'            => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'tgmpa' ), // %1$s = plugin name(s).

            'install_link'                    => _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'tgmpa' ),
            'activate_link'                   => _n_noop( 'Begin activating plugin', 'Begin activating plugins', 'tgmpa' ),

            'return'                          => __( 'Return to Required Plugins Installer', 'tgmpa' ),
            'plugin_activated'                => __( 'Plugin activated successfully.', 'tgmpa' ),
            'complete'                        => __( 'All plugins installed and activated successfully. %s', 'tgmpa' ), // %s = dashboard link.
            'nag_type'                        => 'updated' // Determines admin notice type - can only be 'updated', 'update-nag' or 'error'.
        )
    );

    tgmpa( $plugins, $config );

}


/******************Editor style*******************/


function wpdocs_selectively_enqueue_admin_script( $hook ) {
	wp_enqueue_style( 'my_editor_style1', get_template_directory_uri() . '/assets/css/editor-style-classic.css', array(), '1.0' );
    wp_enqueue_style( 'my_editor_style', get_template_directory_uri() . '/assets/css/editor-style-block.css', array(), '1.0' );
	
}
add_action( 'admin_head', 'wpdocs_selectively_enqueue_admin_script' );


