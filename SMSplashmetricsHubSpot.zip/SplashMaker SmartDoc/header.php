<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<title><?php wp_title('|',true,'right'); bloginfo('name'); ?></title>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<link rel='stylesheet'  href='<?php echo esc_url( get_stylesheet_directory_uri() . '/style.css' ); ?>' type='text/css' media='all' />
	
	<link href="<?php bloginfo('template_url'); ?>/assets/css/style.css" rel="stylesheet" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

